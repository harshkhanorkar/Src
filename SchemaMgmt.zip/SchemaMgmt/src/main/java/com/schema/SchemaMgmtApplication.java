package com.schema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchemaMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchemaMgmtApplication.class, args);
	}

}
