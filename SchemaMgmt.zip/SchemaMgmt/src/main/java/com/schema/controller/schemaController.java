package com.schema.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.schema.model.schemamodel;
import com.schema.service.schemaService;

import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/")
public class schemaController {
	@Autowired
	private schemaService svc;
	
	@PostMapping("/api/schema")
	public schemamodel createSchema(@RequestBody schemamodel schema) {
		return svc.createSchema(schema);
	}
	
	@PutMapping("/api/schema/modify/{id}")
	public ResponseEntity<schemamodel> modifySchema(@RequestBody schemamodel schema,@PathVariable int id){
		return svc.modifySchema(schema, id);
	}
	
	
}
