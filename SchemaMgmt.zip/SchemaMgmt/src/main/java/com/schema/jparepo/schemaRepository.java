package com.schema.jparepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.schema.model.schemamodel;

public interface schemaRepository extends JpaRepository <schemamodel,Integer> {

}
