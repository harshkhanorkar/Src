package com.schema.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="Schema V-Table")
public class schemamodel {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private float schemaVersion;
	private String schemaName;
	private String schemaDescription;
	private String createdBy;
	private String createdOn;
	private String modifiedBy;
	private String modifiedOn;
	public schemamodel() {
		super();
	}
	
//	<-----------------Constructor-------------->
	
	public schemamodel(int id, float schemaVersion, String schemaName, String schemaDescription, String createdBy,
			String createdOn, String modifiedBy, String modifiedOn) {
		super();
		this.id = id;
		this.schemaVersion = schemaVersion;
		this.schemaName = schemaName;
		this.schemaDescription = schemaDescription;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
	}
	
	
//	<------------Getter--and--Setter--------->
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getSchemaVersion() {
		return schemaVersion;
	}
	public void setSchemaVersion(float schemaVersion) {
		this.schemaVersion = schemaVersion;
	}
	public String getSchemaName() {
		return schemaName;
	}
	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}
	public String getSchemaDescription() {
		return schemaDescription;
	}
	public void setSchemaDescription(String schemaDescription) {
		this.schemaDescription = schemaDescription;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
//	<----------ToString----------------------->
	@Override
	public String toString() {
		return "schemamodel [id=" + id + ", schemaVersion=" + schemaVersion + ", schemaName=" + schemaName
				+ ", schemaDescription=" + schemaDescription + ", createdBy=" + createdBy + ", createdOn=" + createdOn
				+ ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + "]";
	}
	
}
