package com.schema.service;

import java.util.ArrayList;

import org.springframework.http.ResponseEntity;

import com.schema.model.schemamodel;

public interface schemaService {
	public schemamodel createSchema(schemamodel schema);
	public ArrayList<schemamodel> getAllSchema();
	public ResponseEntity<schemamodel> modifySchema(schemamodel schema,int id);
}
