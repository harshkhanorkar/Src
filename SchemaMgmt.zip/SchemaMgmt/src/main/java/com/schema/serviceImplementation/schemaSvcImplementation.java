package com.schema.serviceImplementation;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.schema.jparepo.schemaRepository;
import com.schema.model.schemamodel;
import com.schema.service.schemaService;

@Service
public class schemaSvcImplementation implements schemaService {
	@Autowired
	private schemaRepository repo;
	
	@Override
	public schemamodel createSchema(schemamodel schema) {
		return repo.save(schema);
	}
	
	@Override
	public ArrayList<schemamodel> getAllSchema(){
		ArrayList<schemamodel> schemas = new ArrayList<schemamodel>();
		repo.findAll().forEach(schema -> schemas.add(schema) );
		return schemas;
	}
	
	@Override
	public ResponseEntity<schemamodel> modifySchema(schemamodel schema,int id) {
//		schema.setId(schemaid);
//		return repo.save(schema);
		schemamodel modify = repo.findById(id).orElseThrow(null);
		modify.setSchemaName(schema.getSchemaName());
		modify.setSchemaDescription(schema.getSchemaDescription());
		modify.setSchemaVersion(schema.getSchemaVersion());
		modify.setCreatedBy(schema.getCreatedBy());
		repo.save(modify);
		return ResponseEntity.ok(modify);
	}
	
	
}
