package com.schema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchemaMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
